#pragma once
//#include "MyServer.h"
#include "MyClient.h"
//#include "MyForm1.h"
namespace OS9 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	//using namespace System::Net;
	using namespace System::Net::Sockets;
	using namespace System::Text;
	using namespace System::Diagnostics;
	using namespace System::Threading;
	// ... (previous code remains the same)

	using namespace System::Diagnostics;

	
	
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm()
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			//
			// 
	     //clientInstance = gcnew OS9::MyClient();
	      
		}
	public: OS9::MyClient^ clientInstance;
	//public: static OS9::MyServer^ serverInstance = gcnew OS9::MyServer();
	public:bool created = false;
	public:static bool printed = false;
    public: static String^ lastmassage="";
	public: String^ username;
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::RichTextBox^ ChatBox= gcnew System::Windows::Forms::RichTextBox();
	private: System::Windows::Forms::TextBox^ InputBox;

	private: System::Windows::Forms::Button^ SendMessage;



	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			//this->ChatBox = (gcnew System::Windows::Forms::RichTextBox());
			this->InputBox = (gcnew System::Windows::Forms::TextBox());
			this->SendMessage = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// ChatBox
			// 
			this->ChatBox->BackColor = System::Drawing::Color::LightGray;
			this->ChatBox->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ChatBox->Cursor = System::Windows::Forms::Cursors::Arrow;
			this->ChatBox->Font = (gcnew System::Drawing::Font(L"Arial", 12));
			this->ChatBox->Location = System::Drawing::Point(125, 32);
			this->ChatBox->Margin = System::Windows::Forms::Padding(4);
			this->ChatBox->Name = L"ChatBox";
			this->ChatBox->ReadOnly = true;
			this->ChatBox->Size = System::Drawing::Size(727, 557);
			this->ChatBox->TabIndex = 0;
			this->ChatBox->Text = L"";
			// 
			// InputBox
			// 
			this->InputBox->Location = System::Drawing::Point(125, 612);
			this->InputBox->Margin = System::Windows::Forms::Padding(4);
			this->InputBox->Name = L"InputBox";
			this->InputBox->Size = System::Drawing::Size(404, 30);
			this->InputBox->TabIndex = 1;
			this->InputBox->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::InputBox_KeyPress);
			// 
			// SendMessage
			// 
			this->SendMessage->Cursor = System::Windows::Forms::Cursors::Hand;
			this->SendMessage->Location = System::Drawing::Point(751, 611);
			this->SendMessage->Margin = System::Windows::Forms::Padding(4);
			this->SendMessage->Name = L"SendMessage";
			this->SendMessage->Size = System::Drawing::Size(103, 33);
			this->SendMessage->TabIndex = 2;
			this->SendMessage->Text = L"Send";
			this->SendMessage->UseVisualStyleBackColor = true;
			this->SendMessage->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(11, 23);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(1042, 718);
			this->Controls->Add(this->SendMessage);
			this->Controls->Add(this->InputBox);
			this->Controls->Add(this->ChatBox);
			this->Font = (gcnew System::Drawing::Font(L"Arial", 12));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"MyForm";
			this->Text = L"Chat";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		ref class SecondForm : public Form
		{
		private:
			Label^ label;

		public:
			SecondForm()
			{
				this->Text = "Second Window";
				this->Size = Drawing::Size(300, 200);

				label = gcnew Label();
				label->Text = "This is the second window.";
				label->Dock = DockStyle::Fill;
				label->TextAlign = ContentAlignment::MiddleCenter;

				this->Controls->Add(label);
			}
		};

		void OpenSecondWindow(Object^ sender, EventArgs^ e)
		{
			// Hide the current window
			this->Hide();

			// Create and show the second window
			SecondForm^ secondWindow = gcnew SecondForm();
			secondWindow->ShowDialog();

			// Close the current window when the second window is closed
			this->Close();
		}

		void InputBoxKeyPress(Object^ sender, KeyPressEventArgs^ e)
		{
			// Check if the pressed key is Enter
			if (e->KeyChar == '\r')
			{
				// Trigger the Send button click event
				button1_Click(sender, EventArgs::Empty);

				// Prevent the "ding" sound on Enter key press
				e->Handled = true;
			}
		}
		
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ message = InputBox->Text;
		clientInstance = gcnew OS9::MyClient();
				clientInstance->SetUIControlChat(ChatBox);
		clientInstance->SetUIControlInput(InputBox);
		clientInstance->SendMessage(username,message);		
}

	private: System::Void InputBox_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		if (e->KeyChar == '\r')
		{
			// Trigger the Send button click event
			button1_Click(sender, EventArgs::Empty);

			// Prevent the "ding" sound on Enter key press
			e->Handled = true;
		}
	}
		   
		   };
};

