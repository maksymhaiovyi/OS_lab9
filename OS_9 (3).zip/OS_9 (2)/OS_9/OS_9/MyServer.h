#include "MyForm.h"
namespace OS9 {
	using namespace System;
	using namespace System::Net;
	using namespace System::Net::Sockets;
	using namespace System::Text;
	using namespace System::Diagnostics;
	using namespace System::Threading;
	using namespace System::Windows::Forms;
using namespace System::Drawing;
using namespace System::Collections::Generic;

	public ref class MyServer {
	public:
		TcpListener^ server;
		TcpClient^ client;
		List<TcpClient^>^ clients=gcnew List<TcpClient^>();
		System::Windows::Forms::RichTextBox^ textBoxOutput;
		System::Windows::Forms::TextBox^ Inputtext;
		String^ lastmassage;
		bool printed = false;
		public:
		MyServer() {
			textBoxOutput = gcnew System::Windows::Forms::RichTextBox();
			Inputtext = gcnew System::Windows::Forms::TextBox();
			server = gcnew TcpListener(IPAddress::Any,1222);
			server->Start();
			Thread^ serverThread = gcnew Thread(gcnew ThreadStart(this, &MyServer::ListenForClients));
			serverThread->IsBackground = true;
			serverThread->Start();
		}
		void SetUIControlChat(System::Windows::Forms::RichTextBox^ textBox) {
			textBoxOutput = textBox; // Set the UI control reference
		}
		void SetUIControlInput(System::Windows::Forms::TextBox^ textBox) {
			Inputtext = textBox; // Set the UI control reference
		}
		void UpdateUI(Tuple<String^, String^> ^ data) {
			if (textBoxOutput != nullptr) {
				/*if (textBoxOutput->InvokeRequired) {
					textBoxOutput->Invoke(gcnew Action<Tuple<String^, String^>^>(this, &MyServer::UpdateUI), data);
				}
				else*/ {
					// Update the UI controls here
					String^ username = data->Item1;
					String^ message = data->Item2;
					int start = textBoxOutput->TextLength;
					textBoxOutput->AppendText(Environment::NewLine + username+": " + message);
					int end = textBoxOutput->TextLength - start;

					// Set the background color for the entire line
					textBoxOutput->SelectionStart = start;
					textBoxOutput->SelectionLength = end;
					textBoxOutput->SelectionBackColor = Color::White;

					// Set the font and color for the username "You:"

					textBoxOutput->SelectionFont = gcnew Drawing::Font(textBoxOutput->Font, FontStyle::Bold);
					textBoxOutput->SelectionColor = Color::DarkBlue;

					// Set the background color back to the default background color
					textBoxOutput->SelectionBackColor = textBoxOutput->BackColor;

					// Set the padding for the message text
					textBoxOutput->SelectionStart = start + 4;

					textBoxOutput->SelectionFont = gcnew Drawing::Font(textBoxOutput->Font, FontStyle::Regular);
					textBoxOutput->SelectionColor = textBoxOutput->ForeColor;

					// Scroll to the end to show the latest message
					textBoxOutput->ScrollToCaret();

					// Clear the input box
					Inputtext->Clear();
				}
			}
		}
		void ListenForClients() {
			while (true) {
				try {
					//clients = gcnew List<TcpClient^>();
					TcpClient^ client = server->AcceptTcpClient();
					clients->Add(client); // Add the client to the list of connected clients
					Thread^ clientThread = gcnew Thread(gcnew ParameterizedThreadStart(this, &MyServer::HandleClient));
					clientThread->IsBackground = true; // Set client thread as a background thread

					// Start the client thread and pass the connected TcpClient as a parameter
					clientThread->Start(client);
				}
				catch (SocketException^ e) {
					Console::WriteLine("Socket Exception: " + e->Message);
					// Handle the exception or log it
					// Depending on your application's needs, you might not want to break the loop here
					// Instead, you might want to log the exception and continue listening for new clients
					break; // Exit the loop if there's an exception
				}
			}
		}
		void SendMessageToAllClients(String^ username, String^ message) {
			int i = count;
			for each (TcpClient ^ client in clients) {
				if (i == 0)
					i++;
				else {
					String^ arguments = username + " " + message;
					SendMessageToClient(client, arguments); // Send message to each client
				}
			}
		}
		
		
		void HandleClient(Object^ obj) {
			TcpClient^ tcpClient = dynamic_cast<TcpClient^>(obj);
			NetworkStream^ stream = tcpClient->GetStream();

			array<Byte>^ bytes = gcnew array<Byte>(256);
			String^ username = nullptr;
			String^ message = nullptr;

			// Receive the length prefix first
			int bytesRead = stream->Read(bytes, 0, bytes->Length);
			// Receive the actual message based on the length
			String^ receivedData = Encoding::ASCII->GetString(bytes, 0, bytesRead);

			// Extract username and message based on the length
			String^ username1 = receivedData->Split(' ')[0];
			String^ message1 = receivedData->Substring(username->Length + 1); // Skip the space after the username

			// Process the received username and message
			ProcessReceivedMessage(username1,message1);
			//UpdateUI(gcnew Tuple<String^, String^>(username1, message1));
		}


		void ProcessReceivedMessage(String^ username, String^ message) {
			String^ pathToExe = "C:\\Users\\Legion\\Downloads\\Telegram Desktop\\OS9_send (2)\\OS9_send\\RunManager\\x64\\Debug\\RunManager.exe";
			String^ arguments = username + " " + message;

			int result=StartProcess(pathToExe, arguments);
			if (result < 5) {
                SendMessageToAllClients(username, message);
				UpdateUI(gcnew Tuple<String^, String^>(username, message));
			}
			
		}

		int StartProcess(String^ path, String^ arguments) {
			ProcessStartInfo^ startInfo = gcnew ProcessStartInfo();
			startInfo->FileName = path;
			startInfo->Arguments = arguments;
			startInfo->UseShellExecute = false; // Required for redirecting standard output

			startInfo->RedirectStandardOutput = true;
			startInfo->RedirectStandardError = true;

			Process^ process = Process::Start(startInfo);
			process->WaitForExit(); // Wait for the process to finish before continuing

			int exitCode = process->ExitCode; // Retrieve the exit code

			return exitCode;
		}
		void SendMessageToClient(TcpClient^ client, String^ message) {
			NetworkStream^ stream = client->GetStream();

			// Convert the message to bytes
			array<Byte>^ bytesToSend = Encoding::ASCII->GetBytes(message);

			// Send the message to the client
			stream->Write(bytesToSend, 0, bytesToSend->Length);
			stream->Flush(); // Flush the stream to ensure data is sent immediately
		}
	};
}
