namespace OS9 {
    using namespace System;
    using namespace System::Net;
    using namespace System::Net::Sockets;
    using namespace System::Text;
    using namespace System::Windows::Forms;
    using namespace System::Threading;
using namespace System::Drawing;

public ref class MyClient {
public:
    TcpClient^ client;
    NetworkStream^ stream;
    System::Windows::Forms::RichTextBox^ textBoxOutput;
    System::Windows::Forms::TextBox^ Inputtext;

    MyClient() {
        client = gcnew TcpClient();
        client->Connect(IPAddress::Parse("127.0.0.1"), 1222); // Connect to the server IP and port

        stream = client->GetStream();

        Thread^ receiveThread = gcnew Thread(gcnew ThreadStart(this, &MyClient::ReceiveMessages));
        receiveThread->IsBackground = true;
        receiveThread->Start();
    }

    void SetUIControlChat(System::Windows::Forms::RichTextBox^ textBox) {
        textBoxOutput = textBox; // Set the UI control reference
    }

    void SetUIControlInput(System::Windows::Forms::TextBox^ textBox) {
        Inputtext = textBox; // Set the UI control reference
    }

    void ReceiveMessages() {
        array<Byte>^ bytes = gcnew array<Byte>(256);
        while (true) {
            if (stream->DataAvailable) {
                int bytesRead = stream->Read(bytes, 0, bytes->Length);
                String^ receivedData = Encoding::ASCII->GetString(bytes, 0, bytesRead);

                // Split the received data into username and message
                array<String^>^ dataParts = receivedData->Split(' ');
                if (dataParts->Length >= 2) {
                    String^ username = dataParts[0];
                    String^ message = receivedData->Substring(username->Length + 1); // Skip the space after the username
                    // Update UI with the received message
                    UpdateUI(gcnew Tuple<String^, String^>(username, message));
                }
            }
            Thread::Sleep(100); // Introduce a short delay before checking for new messages again
        }
    }
    void UpdateUI(Tuple<String^, String^>^ data) {
        if (textBoxOutput != nullptr) {
            if (textBoxOutput->InvokeRequired) {
                textBoxOutput->Invoke(gcnew Action<Tuple<String^, String^>^>(this, &MyClient::UpdateUI), data);
            }
            else {
                // Update the UI controls here
                String^ username = data->Item1;
                String^ message = data->Item2;
                int start = textBoxOutput->TextLength;
                textBoxOutput->AppendText(Environment::NewLine + username + ": " + message);
                int end = textBoxOutput->TextLength - start;

                // Set the background color for the entire line
                textBoxOutput->SelectionStart = start;
                textBoxOutput->SelectionLength = end;
                textBoxOutput->SelectionBackColor = Color::White;

                // Set the font and color for the username "You:"

                textBoxOutput->SelectionFont = gcnew Drawing::Font(textBoxOutput->Font, FontStyle::Bold);
                textBoxOutput->SelectionColor = Color::DarkBlue;

                // Set the background color back to the default background color
                textBoxOutput->SelectionBackColor = textBoxOutput->BackColor;

                // Set the padding for the message text
                textBoxOutput->SelectionStart = start + 4;

                textBoxOutput->SelectionFont = gcnew Drawing::Font(textBoxOutput->Font, FontStyle::Regular);
                textBoxOutput->SelectionColor = textBoxOutput->ForeColor;

                // Scroll to the end to show the latest message
                textBoxOutput->ScrollToCaret();

                // Clear the input box
                Inputtext->Clear();
            }
        
        }
    }

    //void SendMessage(String^ message) {
    void SendMessage(String^ username,String^ message) {
        String^ combinedMessage = username + " " + message;
        array<Byte>^ bytesToSend = Encoding::ASCII->GetBytes(combinedMessage);
        stream->Write(bytesToSend, 0, bytesToSend->Length);
        stream->Flush();
    }

};

}
